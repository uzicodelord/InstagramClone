<?php return array (
  'notifications' => 'App\\Http\\Livewire\\Notifications',
  'search-users' => 'App\\Http\\Livewire\\SearchUsers',
);