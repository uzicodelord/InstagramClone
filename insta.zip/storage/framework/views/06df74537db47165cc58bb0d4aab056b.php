<?php $__env->startSection('content'); ?>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/sass/home.scss', 'resources/js/home.js', 'resources/js/search.js']); ?>
        <div class="col-md">
            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="card mb-3 p-0" data-post-id="<?php echo e($post->id); ?>">
                    <div class="card-header">
                        <a href="<?php echo e(route('profiles.show', $post->user->name)); ?>" class="userhover">
                            <div class="profile-info-wrapper d-flex align-items-center justify-content-start">
                                <div class="profile-picture-post-comment">
                                    <img src="<?php echo e(asset(Storage::url($post->user->profile_picture))); ?>" alt="<?php echo e($user->name); ?>'s Profile Picture" class="rounded-circle">
                                </div>
                                <div class="profile-info">
                                    <span class="profile-name"><?php echo e($post->user->name); ?></span>

                                    <small class="text-muted">•  <?php echo e($post->created_at->diffForHumans()); ?></small>
                                </div>
                            </div>
                        </a>
                    </div>

                    <div class="card-body">
                        <div class="home-post-image">
                        <img src="<?php echo e(Storage::url($post->image)); ?>" class="post-image" alt="Post image">
                        </div>
                        <br>
                        <a class="like-link userhover" href="#" data-post-id="<?php echo e($post->id); ?>">
                            <i class="like-icon mdi mdi-heart-outline" style="font-size: 30px;"></i>
                        </a>
                        <a href="<?php echo e(route('posts.show', $post->id)); ?>" class="userhover">
                            <i id="like-icon" class="mdi mdi-chat-outline" style="font-size: 30px;"></i>
                        </a>
                        <div>
                            <p id="like-count" class="card-text like-count"><?php echo e($post->likes->count()); ?> <?php echo e(Str::plural('like', $post->likes->count())); ?></p>
                            <p><a class="userhover" href="<?php echo e(route('profiles.show', $post->user->name)); ?>"><?php echo e($post->user->name); ?></a><span style="padding-left: 4px;"><?php echo e($post->caption); ?></span></p>
                        </div>
                    </div>
                    <div id="comment-list" class="card-footer">
                        <?php $__currentLoopData = $post->comments->take(3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="card">
                                <div class="card-body card-body-comment">
                                        <p><a class="userhover" href="<?php echo e(route('profiles.show', $post->user->name)); ?>"><?php echo e($comment->user->name); ?></a><span style="padding-left: 4px;"><?php echo e($comment->content); ?></span></p>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <div class="card-body" style="font-size: 14px;">
                            <?php if($post->comments->count() > 3): ?>
                                <a href="<?php echo e(route('posts.show', $post->id)); ?>" class="text-muted userhover ">View all <?php echo e($post->comments->count()); ?> comments</a>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <form id="comment-form" data-post-id="<?php echo e($post->id); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <div class="d-flex">
                            <input name="content" id="content" placeholder="Add a comment" class="form-control comment" style="width: 90%;" autocomplete="off">
                            <button type="submit" class="btn btn-primary ms-2 comment-button" style="display: none">Post</button>
                        </div>
                    </div>
                </form>
                <hr style="margin-top: 0;">
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <div class="col-md">
            <div class="user-info d-flex align-items-center gap-2">
                <div class="profile-picture-home">
                    <a class="userhover" href="<?php echo e(route('profiles.show', $user->name)); ?>">
                        <img src="<?php echo e(asset(Storage::url($user->profile_picture))); ?>" alt="<?php echo e($user->name); ?>'s Profile Picture" class="rounded-circle mr-2">
                    </a>
                </div>
                <a class="userhover" href="<?php echo e(route('profiles.show', $user->name)); ?>">
                    <span style="font-size: 14px;"><?php echo e($user->name); ?></span>
                </a>
            </div>
            <br>
            <div class="card-body border-1">
                <p>Suggested for you</p>
                    <div class="card-body border-1">
                        <?php $__currentLoopData = $suggested; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $suguser): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if(!$suguser->followers->contains(Auth::user())): ?>
                            <?php if($suguser->id != Auth::id()): ?>
                                <br>
                                <div class="card">
                                    <div class="card-body d-flex align-items-center gap-2">
                                        <div class="profile-picture-home">
                                            <img src="<?php echo e(asset(Storage::url($suguser->profile_picture))); ?>" alt="<?php echo e($suguser->name); ?>'s Profile Picture" class="rounded-circle mr-2">
                                        </div>
                                        <a class="userhover" href="<?php echo e(route('profiles.show', $suguser->name)); ?>">
                                            <span style="font-size: 14px;"><?php echo e($suguser->name); ?></span>
                                        </a>
                                    </div>
                                </div>
                            <?php endif; ?>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                    </div>

        </div>
        </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\instagram-clone\resources\views/home.blade.php ENDPATH**/ ?>