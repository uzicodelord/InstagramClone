<?php $__env->startSection('content'); ?>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/sass/home.scss', 'resources/js/follow.js', 'resources/js/home.js', 'resources/js/fwmodals.js']); ?>

    <div class="col-6">
        <div class="user-profile-info d-flex align-items-start gap-4">
            <div class="profile-picture-container">
                <img src="<?php echo e(asset(Storage::url($user->profile_picture))); ?>" alt="<?php echo e($user->name); ?>'s Profile Picture" class="rounded-circle">
            </div>
            <div class="d-flex flex-column">
                <div class="d-flex align-items-center justify-content-center gap-5">
                    <div>
                    </div>
                    <h3 class="mb-0"><?php echo e($user->name); ?></h3>
                    <div class="d-flex align-items-center">
                        <?php if(Auth::user()->id == $user->id): ?>
                                <button class="btn btn-primary unfwbutton" id="edit-profile-btn">Edit Profile</button>
                        <?php else: ?>
                                <?php endif; ?>
                        <?php if(auth()->check() && auth()->user()->id !== $user->id): ?>

                            <?php if(auth()->user()->isFollowing($user)): ?>
                                <form action="<?php echo e(route('unfollow', $user)); ?>" method="post">
                                    <?php echo e(csrf_field()); ?>

                                    <?php echo e(method_field('DELETE')); ?>

                                    <button type="submit" class="btn unfwbutton">Following <i style="font-size: 12px;" class="mdi mdi-check"></i></button>
                                </form>
                            <?php else: ?>
                                <form action="<?php echo e(route('follow', $user)); ?>" method="post">
                                    <?php echo e(csrf_field()); ?>

                                    <button type="submit" class="btn btn-primary fwbutton">Follow</button>
                                </form>
                                <?php endif; ?>
                                <a href="<?php echo e(route('chats.index', ['receiver_id' => $user->id])); ?>" class="userhover text-white d-flex align-items-center">
                                &nbsp<button type="submit" class="btn btn-primary unfwbutton">Message</button>
                                </a>
                            <?php endif; ?>
                    </div>
                </div>
                <div class="d-flex align-items-center flex-wrap gap-sm-5 mt-2" style="padding-top: 10px;">
                    <span class="" style="font-size: 14px"><b><?php echo e($user->posts->count()); ?></b> <?php echo e(Str::plural('post', $user->posts->count())); ?></span>
                    <a class="userhover" id="followers-btn" style="font-size: 14px;cursor: pointer"><b><?php echo e($user->followersCount()); ?></b> <?php echo e(Str::plural('follower', $user->followersCount())); ?></a>
                    <a class="userhover" id="following-btn" style="font-size: 14px;cursor: pointer;"><b><?php echo e($user->followingCount()); ?></b> <?php echo e(Str::plural('following', $user->followingCount())); ?></a>
                </div>
                <span style="padding-top: 10px;font-size: 14px;"><?php echo e($user->bio); ?></span>
            </div>
        </div>
            <hr>
        <div class="post-grid">
            <?php if($user->is_private && !auth()->user()->isFollowing($user) && $user->id !== auth()->id()): ?>
                <div class="container" style="border: 1px solid #737373;padding: 50px;">
                <div class="text-center">
                    <p>This Account is Private</p>
                    <p>Follow to see their photos and videos.</p>

                </div>
                </div>
            <?php else: ?>
                <?php $__currentLoopData = $user->posts->sortByDesc('created_at'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="post-container">
                        <a href="<?php echo e(route('posts.show', $post->id)); ?>">
                            <img src="<?php echo e(Storage::url($post->image)); ?>" class="gridimage"
                                 data-comments="<?php echo e($post->comments->count()); ?>" data-likes="<?php echo e($post->likes->count()); ?>">
                        </a>
                        <div class="count-overlay">
                            <div class="count-text">
                                <span class="likes-count"><a class="nobac" href="<?php echo e(route('posts.show', $post->id)); ?>"><i class="mdi mdi-heart"></i> <?php echo e($post->likes->count()); ?></a></span>
                                <span class="comments-count"><a class="nobac" href="<?php echo e(route('posts.show', $post->id)); ?>"><i class="mdi mdi-chat"></i> <?php echo e($post->comments->count()); ?></a></span>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </div>
    </div>

    <div id="followingmodal" class="modal">
        <div class="modal-dialog" style="max-width: 500px;">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="createPostModalLabel">Followings</h5>
                    <button style="background-color: black;border: none" type="button" class="followingclose" data-dismiss="modal" aria-label="Close">
                        <i class="mdi mdi-close" style="color: #fff;font-size: 20px;"></i>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="following">
                        <ul>
                            <?php $__currentLoopData = $followings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $following): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <a href="<?php echo e(route('profiles.show', $following->name)); ?>" class="userhover">
                                    <div class="profile-picture-post-comment d-flex gap-2 justify-content-center">
                                        <img src="<?php echo e(asset(Storage::url($following->profile_picture))); ?>" alt="<?php echo e($following->name); ?>'s Profile Picture" class="rounded-circle">
                                        <h6 class="mb-2" style="padding-top: 5px;"><?php echo e($following->name); ?></h6>
                                    </div>
                                </a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div id="followersmodal" class="modal">
        <div class="modal-dialog" style="max-width: 500px;">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="createPostModalLabel">Followers</h5>
                    <button style="background-color: black;border: none" type="button" class="followersclose" data-dismiss="modal" aria-label="Close">
                        <i class="mdi mdi-close" style="color: #fff;font-size: 20px;"></i>
                    </button>
                </div>
                <div class="modal-body">
                            <?php $__currentLoopData = $followers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $follower): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <a href="<?php echo e(route('profiles.show', $follower->name)); ?>" class="userhover">
                                    <div class="profile-picture-post-comment d-flex gap-2 justify-content-center">
                                        <img src="<?php echo e(asset(Storage::url($follower->profile_picture))); ?>" alt="<?php echo e($follower->name); ?>'s Profile Picture" class="rounded-circle">
                                        <h6 class="mb-2" style="padding-top: 5px;"><?php echo e($follower->name); ?></h6>
                                    </div>
                                </a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
    <div class="col-2"></div>
    <div id="edit-profile-modal" class="modal">
        <div class="modal-dialog" style="max-width: 500px;">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="createPostModalLabel">Edit Profile</h5>
                    <button style="background-color: black;border: none" type="button" class="editprofileclose" data-dismiss="modal" aria-label="Close">
                        <i class="mdi mdi-close" style="color: #fff;font-size: 20px;"></i>
                    </button>
                </div>
                <div class="modal-body">
                    <form method="POST" action="<?php echo e(route('profiles.update', $user->id)); ?>" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>

                        <div class="form-group">
                            <label for="name">Username</label>
                            <input type="text" name="name" id="name" value="<?php echo e(old('name', $user->name)); ?>" class="form-control comment <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="form-group">
                            <label for="email">Email</label>
                            <input type="email" name="email" id="email" value="<?php echo e(old('email', $user->email)); ?>" class="form-control comment <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="form-group">
                            <label for="bio">Bio</label>
                            <textarea style="resize: none;" name="bio" id="bio" class="form-control comment <?php $__errorArgs = ['bio'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"><?php echo e(old('bio', $user->bio)); ?></textarea>
                            <?php $__errorArgs = ['bio'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="form-group">
                            <label for="is_private">Make profile private</label>
                            <div class="form-check">
                                <input type="checkbox" class="form-check-input" id="is_private" name="is_private" <?php echo e($user->is_private ? 'checked' : ''); ?>>
                                <label class="form-check-label" for="is_private">Only allow followers to see my posts</label>
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="profile_picture">Profile Picture</label>
                            <input type="file" name="profile_picture" id="profile_picture" class="custom-file-input <?php $__errorArgs = ['profile_picture'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                            <?php $__errorArgs = ['profile_picture'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-primary">Save Changes</button>
                </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\instagram-clone\resources\views/profiles/show.blade.php ENDPATH**/ ?>