<?php $__env->startSection('content'); ?>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/sass/home.scss', 'resources/js/comment-like.js']); ?>
        <div class="col-md">
            <div class="post-picture">
            <img src="<?php echo e(Storage::url($post->image)); ?>" alt="Post image">
            </div>
        </div>
        <div class="col-md">
            <div class="card" data-post-id="<?php echo e($post->id); ?>">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <a href="<?php echo e(route('profiles.show', $post->user->name)); ?>" class="userhover">
                        <div class="profile-picture-post-comment d-flex gap-2 justify-content-center">
                        <img src="<?php echo e(asset(Storage::url($post->user->profile_picture))); ?>" alt="<?php echo e($user->name); ?>'s Profile Picture" class="rounded-circle">
                            <h6 class="mb-2" style="padding-top: 5px;"><?php echo e($post->user->name); ?></h6>
                        </div>
                    </a>
                    <?php if(Auth::check() && Auth::user()->id === $user->id): ?>
                        <div class="dropdown">
                              <span class="btn dropdown-toggle border-0" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i style="font-size: 24px;color: #fff;" class="mdi mdi-dots-horizontal"></i>
                              </span>
                            <div class="dropdown-menu dropdown-menu-right bg-black" aria-labelledby="dropdownMenuButton">
                                <button type="button" class="dropdown-item userhover" id="open-edit-modal-btn" style="color: #fff;">Edit Post</button>
                                <button type="button" class="dropdown-item userhover text-danger" id="open-delete-modal-btn">Delete Post</button>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
                <!-- MODALS -->
                <div id="edit-post-modal" class="modal">
                    <div class="modal-dialog" style="max-width: 500px;">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="createPostModalLabel">Edit Post</h5>
                                <button style="background-color: black;border: none" type="button" class="editclose" data-dismiss="modal" aria-label="Close">
                                    <i class="mdi mdi-close" style="color: #fff;font-size: 20px;"></i>
                                </button>
                            </div>
                            <div class="modal-body">
                                <form action="<?php echo e(route('posts.update', $post->id)); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('PUT'); ?>
                                    <div class="form-group">
                                        <label for="post-caption" class="col-form-label">Caption:</label>
                                        <textarea style="resize: none;" class="form-control comment" id="post-caption" name="caption"><?php echo e(old('caption', $post->caption)); ?></textarea>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="submit" class="btn btn-primary comment-button">Save changes</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
                <div id="delete-post-modal" class="modal">
                    <div class="modal-dialog" style="max-width: 500px;">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="createPostModalLabel">Delete Post</h5>
                                <button style="background-color: black;border: none" type="button" class="deleteclose" data-dismiss="modal" aria-label="Close">
                                    <i class="mdi mdi-close" style="color: #fff;font-size: 20px;"></i>
                                </button>
                            </div>
                            <div class="modal-body">
                                <p>Are you sure you want to delete this post?</p>
                            </div>
                            <div class="modal-footer">
                                <form action="<?php echo e(route('posts.destroy', $post->id)); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-danger">Delete</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- MODALS -->
                <hr>
                <div class="card-footer">
                    <div class="d-flex align-items-start">
                        <a class="userhover" href="<?php echo e(route('profiles.show', $user->name)); ?>">
                            <div class="profile-picture-post-comment">
                            <img src="<?php echo e(asset(Storage::url($user->profile_picture))); ?>" class="rounded-circle">
                            </div>
                        </a>
                        <div class="card-body card-body-comment ml-2">
                            <p>
                                <a class="userhover" href="<?php echo e(route('profiles.show', $user->name)); ?>">
                                    <?php echo e($user->name); ?>

                                </a>
                                <span style="font-size: 10px;padding-left: 4px;"><?php echo e($post->caption); ?></span>
                            </p>
                            <p class="text-muted" style="font-size: 10px;"><?php echo e($post->created_at->diffForHumans()); ?></p>
                        </div>
                    </div>
                        <div class="col-md">
                            <div id="comment-list" style="overflow-y: scroll; height: 450px;">
                                <?php $__currentLoopData = $post->comments->sortByDesc(function($comment) {
                                    return $comment->likes->count();
                                }); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="card" style="padding-top: 10px;">
                                        <div class="d-flex align-items-start">
                                            <a class="userhover" href="<?php echo e(route('profiles.show', $comment->user->name)); ?>">
                                                <div class="profile-picture-post-comment">
                                                <img src="<?php echo e(asset(Storage::url($comment->user->profile_picture))); ?>" class="rounded-circle">
                                                </div>
                                            </a>
                                            <div class="card-body card-body-comment ml-2">
                                                <p>
                                                    <a class="userhover" href="<?php echo e(route('profiles.show', $comment->user->name)); ?>">
                                                        <?php echo e($comment->user->name); ?>

                                                    </a>
                                                    <span style="font-size: 10px;padding-left: 4px;"><?php echo e($comment->content); ?></span>
                                                </p>
                                                <p class="text-muted" style="font-size: 10px;"><?php echo e($comment->created_at->diffForHumans()); ?>

                                                    <a href="#" class="like-comment-links userhover iconhover" data-comment-id="<?php echo e($comment->id); ?>">
                                                        <i style="font-size: 12px;float: right" class="mdi mdi-heart liked-comment-icons"></i>
                                                    </a>
                                                    <br>
                                                    <span style="padding-left: 0;font-size: 11px;color: #fff;" class="ml-2 liked-comment-counts"><?php echo e($comment->likes->count()); ?> <?php echo e(Str::plural('like', $comment->likes->count())); ?></span>
                                                </p>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>

                            <div class="">
                            <form id="comment-form" data-post-id="<?php echo e($post->id); ?>">
                                <?php echo csrf_field(); ?>
                                <div class="form-group">
                                    <a class="like-link userhover iconhover" href="#" data-post-id="<?php echo e($post->id); ?>">
                                        <i class="like-icon mdi mdi-heart-outline" style="font-size: 30px;"></i>
                                    </a>
                                    <a class="userhover iconhover" href="#" data-post-id="<?php echo e($post->id); ?>">
                                        <i class="mdi mdi-chat-outline" style="font-size: 30px;"></i>
                                    </a>
                                    <div>
                                        <p id="like-count" class="card-text like-count"><?php echo e($post->likes->count()); ?> <?php echo e(Str::plural('like', $post->likes->count())); ?></p>
                                    </div>
                                    <p class="text-muted"><?php echo e($post->created_at->diffForHumans()); ?></p>
                                    <hr>
                                    <div class="d-flex">
                                        <input name="content" id="content" placeholder="Add a comment" class="form-control comment" style="width: 90%;" autocomplete="off">
                                        <button type="submit" class="btn btn-primary ms-2 comment-button">Post</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\instagram-clone\resources\views/posts/show.blade.php ENDPATH**/ ?>