<?php $__env->startSection('content'); ?>
    <div class="col-8">
    <h1>Notifications</h1>
    <ul>
        <?php $__currentLoopData = $notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <br>
            <div style="display: flex; align-items: center;">
                <a href="<?php echo e(route('profiles.show', $notification->data['user_name'])); ?>" class="userhover">
                    <div class="profile-picture-post-comment d-flex gap-2 justify-content-start">
                        <img src="<?php echo e(asset(Storage::url($notification->data['user_profile_picture']))); ?>" alt="<?php echo e($notification->data['user_name']); ?>'s Profile Picture" class="rounded-circle">
                    </div>
                </a>
                <span style="padding: 5px;"><?php echo e($notification->data['message']); ?></span>
                <div class="profile-picture-post-comment">
                    <a href="<?php echo e(route('posts.show', $notification->data['post_id'])); ?>">
                        <img src="<?php echo e(asset(Storage::url($notification->data['post_image']))); ?>">
                    </a>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\instagram-clone\resources\views/notifications/index.blade.php ENDPATH**/ ?>