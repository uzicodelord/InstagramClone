<div>
    <input class="form-control comment" type="text" wire:model="searchTerm" placeholder="Search users...">
    <?php if($searchTerm != ""): ?>
        <?php if(count($users) > 0): ?>
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <hr>
                <a href="<?php echo e(route('profiles.show', $user->name)); ?>" class="userhover">
                    <div class="profile-info-wrapper d-flex align-items-center justify-content-start">
                        <div class="profile-picture-post-comment">
                            <img src="<?php echo e(asset(Storage::url($user->profile_picture))); ?>" alt="<?php echo e($user->name); ?>'s Profile Picture" class="rounded-circle">
                        </div>
                        <div class="profile-info">
                            <span class="profile-name"><?php echo e($user->name); ?></span>
                        </div>
                    </div>
                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
            <div class="not-found">Not found</div>
        <?php endif; ?>
    <?php endif; ?>
</div>
<?php /**PATH C:\xampp\htdocs\instagram-clone\resources\views/livewire/search-users.blade.php ENDPATH**/ ?>