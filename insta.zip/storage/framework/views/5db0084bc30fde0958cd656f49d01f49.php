<?php $__env->startSection('content'); ?>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/sass/home.scss', 'resources/js/follow.js', 'resources/js/home.js']); ?>

    <div class="col-9">
        <div class="post-grid" >

            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if(!$post->user->is_private): ?>
                <div class="post-container">
                    <a href="<?php echo e(route('posts.show', $post->id)); ?>">
                        <img src="<?php echo e(Storage::url($post->image)); ?>" class="gridimage"
                             data-comments="<?php echo e($post->comments->count()); ?>" data-likes="<?php echo e($post->likes->count()); ?>">
                    </a>
                    <div class="count-overlay">
                        <div class="count-text">
                            <span class="likes-count"><a class="nobac" href="<?php echo e(route('posts.show', $post->id)); ?>"><i class="mdi mdi-heart"></i> <?php echo e($post->likes->count()); ?></a></span>
                            <span class="comments-count"><a class="nobac" href="<?php echo e(route('posts.show', $post->id)); ?>"><i class="mdi mdi-chat"></i> <?php echo e($post->comments->count()); ?></a></span>
                        </div>
                    </div>
                </div>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <div  class="post-grid d-flex justify-content-center align-items-center flex-wrap">
            <?php echo $posts->links(); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\instagram-clone\resources\views/posts/index.blade.php ENDPATH**/ ?>