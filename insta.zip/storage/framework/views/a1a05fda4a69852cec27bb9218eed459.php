<?php
 ?><?php /**PATH C:\xampp\htdocs\instagram-clone\resources\views/posts/edit.blade.php ENDPATH**/ ?>