<div class="post-container">
    <a href="<?php echo e(route('posts.show', $post->id)); ?>">
        <img src="<?php echo e(Storage::url($post->image)); ?>" class="gridimage" data-comments="<?php echo e($post->comments->count()); ?>" data-likes="<?php echo e($post->likes->count()); ?>">
    </a>
    <div class="count-overlay">
        <div class="count-text">
            <span class="likes-count"><a class="nobac" href="<?php echo e(route('posts.show', $post->id)); ?>"><i class="fas fa-heart"></i> <?php echo e($post->likes->count()); ?></a></span>
            <span class="comments-count"><a class="nobac" href="<?php echo e(route('posts.show', $post->id)); ?>"><i class="fas fa-comment"></i> <?php echo e($post->comments->count()); ?></a></span>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\instagram-clone\resources\views/posts/post.blade.php ENDPATH**/ ?>